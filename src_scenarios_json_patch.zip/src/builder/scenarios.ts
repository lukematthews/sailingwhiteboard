// src/builder/scenarios.ts
import type { ProjectFile } from "./projectTypes";
import raw from "./scenarios.json";

/**
 * Scenarios are now DATA-DRIVEN.
 *
 * - The WelcomeOverlay reads titles/desc/badges from scenarios.json.
 * - Each scenario contains a full ProjectFile payload (version 4).
 * - Import/export is encouraged to use the ScenarioFile wrapper (see useProjectIO).
 */

export type ScenarioKey =
  | "start-sequence"
  | "boat-interaction"
  | "protest-replay"
  | "blank"
  | "five-boat-start-rack";

export type ScenarioDefinition = {
  key: ScenarioKey;
  title: string;
  desc: string;
  badge?: string;
  hidden?: boolean;
  project: ProjectFile;
};

type ScenariosJson = {
  schemaVersion: number;
  scenarios: ScenarioDefinition[];
};

const parsed = raw as unknown as ScenariosJson;

function assertScenarioKey(key: string): asserts key is ScenarioKey {
  const ok =
    key === "start-sequence" ||
    key === "boat-interaction" ||
    key === "protest-replay" ||
    key === "blank" ||
    key === "five-boat-start-rack";
  if (!ok) {
    throw new Error(`Unknown ScenarioKey in scenarios.json: ${key}`);
  }
}

function deepClone<T>(v: T): T {
  // ProjectFile is plain JSON data; this is enough and avoids accidental mutation.
  return JSON.parse(JSON.stringify(v)) as T;
}

export const SCENARIOS: ScenarioDefinition[] = (() => {
  const list = Array.isArray(parsed?.scenarios) ? parsed.scenarios : [];
  const cleaned: ScenarioDefinition[] = [];

  for (const s of list) {
    if (!s || typeof s !== "object") continue;
    if (typeof (s as any).key !== "string") continue;
    assertScenarioKey((s as any).key);

    cleaned.push({
      key: (s as any).key,
      title: typeof (s as any).title === "string" ? (s as any).title : (s as any).key,
      desc: typeof (s as any).desc === "string" ? (s as any).desc : "",
      badge: typeof (s as any).badge === "string" ? (s as any).badge : undefined,
      hidden: !!(s as any).hidden,
      project: (s as any).project as ProjectFile,
    });
  }

  return cleaned;
})();

export const SCENARIO_KEYS: ScenarioKey[] = SCENARIOS.filter((s) => !s.hidden).map(
  (s) => s.key,
);

export function getScenarioByKey(key: ScenarioKey): ScenarioDefinition | undefined {
  return SCENARIOS.find((s) => s.key === key);
}

export function getScenarioProjectFile(key: ScenarioKey): ProjectFile {
  const s = getScenarioByKey(key);
  if (!s) {
    // fall back to blank if missing
    const blank = SCENARIOS.find((x) => x.key === "blank");
    return deepClone(blank?.project ?? ({} as ProjectFile));
  }
  return deepClone(s.project);
}
