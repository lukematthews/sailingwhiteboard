import { uid } from "../lib/ids";
import type { ProjectFile } from "./projectTypes";

export type ScenarioKey =
  | "start-sequence"
  | "boat-interaction"
  | "protest-replay"
  | "blank";

// If you ever want to render a dynamic list of scenarios in UI.
export const SCENARIO_KEYS: ScenarioKey[] = [
  "start-sequence",
  "boat-interaction",
  "protest-replay",
  "blank",
];

/**
 * Get a ready-to-import ProjectFile for a scenario.
 *
 * IDs are generated at runtime to avoid collisions if you load scenarios
 * multiple times in one session.
 */
export function getScenarioProjectFile(key: ScenarioKey): ProjectFile {
  switch (key) {
    case "start-sequence":
      return scenarioStartSequence();
    case "boat-interaction":
      return scenarioBoatInteraction();
    case "protest-replay":
      return scenarioProtestReplay();
    case "blank":
      return scenarioBlank();
  }
}

// ---------------------------------------------------------------------------
// Scenario builders
// ---------------------------------------------------------------------------

function baseProject(): Omit<ProjectFile, "boats" | "stepsByBoatId"> {
  return {
    version: 4,
    durationMs: 120000,
    fps: 10,
    keyframesByBoatId: {},
    marks: [
      { id: uid(), name: "Windward", type: "round", x: 520, y: 150 },
      { id: uid(), name: "Leeward", type: "round", x: 280, y: 450 },
    ],
    wind: { fromDeg: 0, speedKt: 15 },
    startLine: {
      committee: { x: 360, y: 360 },
      pin: { x: 480, y: 360 },
      startBoatId: null,
    },
    flags: [],
    flagClipsByFlagId: {},
  };
}

function scenarioStartSequence(): ProjectFile {
  const b1 = uid();
  const b2 = uid();

  return {
    ...baseProject(),
    durationMs: 120000,
    boats: [
      {
        id: b1,
        label: "Boat 1",
        color: "#22c55e",
        x: 400,
        y: 320,
        headingDeg: 0,
      },
      {
        id: b2,
        label: "Boat 2",
        color: "#3b82f6",
        x: 460,
        y: 340,
        headingDeg: 0,
      },
    ],
    stepsByBoatId: {
      [b1]: [
        { id: uid(), tMs: 0, x: 400, y: 320, headingMode: "auto" },
        { id: uid(), tMs: 30000, x: 415, y: 290, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 430, y: 260, headingMode: "auto" },
        { id: uid(), tMs: 90000, x: 445, y: 230, headingMode: "auto" },
        { id: uid(), tMs: 120000, x: 460, y: 200, headingMode: "auto" },
      ],
      [b2]: [
        { id: uid(), tMs: 0, x: 460, y: 340, headingMode: "auto" },
        { id: uid(), tMs: 30000, x: 475, y: 310, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 490, y: 280, headingMode: "auto" },
        { id: uid(), tMs: 90000, x: 505, y: 250, headingMode: "auto" },
        { id: uid(), tMs: 120000, x: 520, y: 220, headingMode: "auto" },
      ],
    },
  };
}

function scenarioBoatInteraction(): ProjectFile {
  const port = uid();
  const starboard = uid();

  return {
    ...baseProject(),
    durationMs: 60000,
    boats: [
      {
        id: starboard,
        label: "Starboard",
        color: "#22c55e",
        x: 380,
        y: 340,
        headingDeg: 0,
      },
      {
        id: port,
        label: "Port",
        color: "#ef4444",
        x: 500,
        y: 380,
        headingDeg: 315,
      },
    ],
    stepsByBoatId: {
      [starboard]: [
        { id: uid(), tMs: 0, x: 380, y: 340, headingMode: "auto" },
        { id: uid(), tMs: 20000, x: 395, y: 305, headingMode: "auto" },
        { id: uid(), tMs: 40000, x: 410, y: 270, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 425, y: 235, headingMode: "auto" },
      ],
      [port]: [
        { id: uid(), tMs: 0, x: 500, y: 380, headingMode: "auto" },
        { id: uid(), tMs: 20000, x: 470, y: 350, headingMode: "auto" },
        { id: uid(), tMs: 40000, x: 445, y: 320, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 425, y: 295, headingMode: "auto" },
      ],
    },
    marks: [{ id: uid(), name: "Mark", type: "round", x: 440, y: 210 }],
    wind: { fromDeg: 10, speedKt: 14 },
  };
}

function scenarioProtestReplay(): ProjectFile {
  const a = uid();
  const b = uid();
  const c = uid();
  const protestFlag = uid();

  return {
    ...baseProject(),
    durationMs: 90000,
    fps: 10,
    boats: [
      {
        id: a,
        label: "A",
        color: "#22c55e",
        x: 360,
        y: 390,
        headingDeg: 0,
      },
      {
        id: b,
        label: "B",
        color: "#3b82f6",
        x: 420,
        y: 410,
        headingDeg: 0,
      },
      {
        id: c,
        label: "C",
        color: "#f59e0b",
        x: 480,
        y: 430,
        headingDeg: 0,
      },
    ],
    stepsByBoatId: {
      [a]: [
        { id: uid(), tMs: 0, x: 360, y: 390, headingMode: "auto" },
        { id: uid(), tMs: 30000, x: 370, y: 340, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 385, y: 285, headingMode: "auto" },
        { id: uid(), tMs: 90000, x: 405, y: 235, headingMode: "auto" },
      ],
      [b]: [
        { id: uid(), tMs: 0, x: 420, y: 410, headingMode: "auto" },
        { id: uid(), tMs: 30000, x: 415, y: 360, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 410, y: 310, headingMode: "auto" },
        { id: uid(), tMs: 90000, x: 405, y: 265, headingMode: "auto" },
      ],
      [c]: [
        { id: uid(), tMs: 0, x: 480, y: 430, headingMode: "auto" },
        { id: uid(), tMs: 30000, x: 460, y: 390, headingMode: "auto" },
        { id: uid(), tMs: 60000, x: 440, y: 350, headingMode: "auto" },
        { id: uid(), tMs: 90000, x: 420, y: 315, headingMode: "auto" },
      ],
    },
    marks: [
      { id: uid(), name: "Windward", type: "round", x: 520, y: 170 },
      { id: uid(), name: "Gate L", type: "round", x: 310, y: 470 },
      { id: uid(), name: "Gate R", type: "round", x: 390, y: 470 },
    ],
    wind: { fromDeg: 0, speedKt: 16 },
    startLine: {
      committee: { x: 350, y: 430 },
      pin: { x: 510, y: 430 },
      startBoatId: null,
    },
    flags: [
      {
        id: protestFlag,
        code: "P",
        x: 80,
        y: 160,
      },
    ],
    flagClipsByFlagId: {
      [protestFlag]: [
        {
          id: uid(),
          startMs: 25000,
          endMs: 45000,
          code: "P",
        },
      ],
    },
  };
}

function scenarioBlank(): ProjectFile {
  return {
    version: 4,
    durationMs: 60000,
    fps: 10,
    boats: [],
    keyframesByBoatId: {},
    stepsByBoatId: {},
    marks: [],
    wind: { fromDeg: 0, speedKt: 15 },
    startLine: {
      committee: { x: 360, y: 360 },
      pin: { x: 480, y: 360 },
      startBoatId: null,
    },
    flags: [],
    flagClipsByFlagId: {},
  };
}
