---
id: "RRS 18"
title: "Mark-Room"
ruleNumber: 18
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
