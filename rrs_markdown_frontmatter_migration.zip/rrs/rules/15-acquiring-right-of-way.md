---
id: "RRS 15"
title: "Acquiring Right of Way"
ruleNumber: 15
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
