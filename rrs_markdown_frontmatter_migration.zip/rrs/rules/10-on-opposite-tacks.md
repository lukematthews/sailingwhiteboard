---
id: "RRS 10"
title: "On Opposite Tacks"
ruleNumber: 10
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
