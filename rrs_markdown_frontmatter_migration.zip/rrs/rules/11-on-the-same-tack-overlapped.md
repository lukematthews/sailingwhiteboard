---
id: "RRS 11"
title: "On the Same Tack, Overlapped"
ruleNumber: 11
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
