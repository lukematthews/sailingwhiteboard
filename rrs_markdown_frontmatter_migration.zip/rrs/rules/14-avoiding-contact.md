---
id: "RRS 14"
title: "Avoiding Contact"
ruleNumber: 14
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
