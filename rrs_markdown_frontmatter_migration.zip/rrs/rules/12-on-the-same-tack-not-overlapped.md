---
id: "RRS 12"
title: "On the Same Tack, Not Overlapped"
ruleNumber: 12
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
