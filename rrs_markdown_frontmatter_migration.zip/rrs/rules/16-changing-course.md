---
id: "RRS 16"
title: "Changing Course"
ruleNumber: 16
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
