---
id: "RRS 13"
title: "While Tacking"
ruleNumber: 13
type: "rrs-rule"
sourcePublisher: "World Sailing"
sourceEdition: "2025-2028"
---
<!-- TODO: Add official rule text here (markdown). -->
