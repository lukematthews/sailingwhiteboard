---
type: "rrs-root"
schemaVersion: 1
---

# Racing Rules of Sailing

## Rules

This folder is generated from rrsRules.json and will eventually include Part/Section structure.

